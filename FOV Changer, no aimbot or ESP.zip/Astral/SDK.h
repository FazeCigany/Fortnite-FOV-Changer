#pragma once
#include <cstdint>

namespace SDK
{
	namespace Offsets
	{
		namespace Game
		{
			constexpr uint64_t UWorld = 0x7CCB270;
			constexpr uint64_t Game_Instance = 0x170;
			constexpr uint64_t Levels = 0x138;
		}

		namespace LocalPlayer
		{
			constexpr uint64_t Local_Player = 0x0;
		}
	}
}