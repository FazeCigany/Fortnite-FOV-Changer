#include "globals.h"

namespace Globals {
	int rWidth = 0;
	int rHeight = 0;
	HWND tWnd = 0x0;
	HWND hWnd = 0x0;
	HWND hMsg = 0x0;
	D3DXMATRIX vMatrix;
	HANDLE hGame = 0x0;
	DWORD dwBase = 0x0;
	int iFPS = 0;
	bool bShowMenu = false;
}
