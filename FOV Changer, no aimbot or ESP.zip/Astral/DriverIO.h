//
//	Cheetos 1.0 - made by Astral.
//	File: DriverIO.h
//

#pragma once
#include <cstring>
#define ctl_write   CTL_CODE(FILE_DEVICE_UNKNOWN, 0x0424, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define ctl_read    CTL_CODE(FILE_DEVICE_UNKNOWN, 0x0425, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)
#define ctl_base    CTL_CODE(FILE_DEVICE_UNKNOWN, 0x0426, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)

typedef struct info_t {
	int pid = 0;
	void* address;
	void* value;
	SIZE_T size;
	void* data;
}info, * p_info;

template <typename Type>
Type readMemory(void* Driver, unsigned long int Process_Identifier, unsigned long long int Address)
{
	info_t Input_Output_Data;

	Input_Output_Data.pid = Process_Identifier;

	Input_Output_Data.address = (void*)Address;

	Type Return_Value;

	Input_Output_Data.value = &Return_Value;

	Input_Output_Data.size = sizeof Type;

	unsigned long int Readed_Bytes_Amount;

	DeviceIoControl(Driver, ctl_read, &Input_Output_Data, sizeof Input_Output_Data, &Input_Output_Data, sizeof Input_Output_Data, &Readed_Bytes_Amount, nullptr);

	return *(Type*)&Return_Value;
}

template <typename Type>
Type writeMemory(void* Driver, unsigned long int Process_Identifier, unsigned long long int Address, float Value)
{
	info_t Input_Output_Data;

	Input_Output_Data.pid = Process_Identifier;

	Input_Output_Data.address = (void*)Address;

	Input_Output_Data.value = static_cast<void*>(&Value);

	Input_Output_Data.size = sizeof Type;

	unsigned long int Readed_Bytes_Amount;

	DeviceIoControl(Driver, ctl_write, &Input_Output_Data, sizeof Input_Output_Data, &Input_Output_Data, sizeof Input_Output_Data, &Readed_Bytes_Amount, nullptr);

	Type Return_Data;

	Input_Output_Data.data = &Return_Data;

	return *(Type*)&Return_Data;
}
