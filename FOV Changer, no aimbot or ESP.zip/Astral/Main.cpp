#include "Main.h"
#include "DriverIO.h"
#include "Menu.h"

char WINNAME[16] = "Name";
char tWindowName[256] = "Fortnite  ";


HANDLE Driver = CreateFileW(_xor_(L"\\\\.\\Printer0x0").c_str(), GENERIC_READ, 0, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);

DWORD procID;
ULONG processID;

HWND hwnd = NULL;
HWND tWnd;

RECT tSize;

int Width = 0;
int Height = 0;

MARGINS MARGIN = { 0, 0, Globals::rWidth, Globals::rHeight };

uint64_t BaseAddress;
DWORD_PTR Uworld;
DWORD_PTR Localplayer;
DWORD_PTR Ulevel;


HINSTANCE hInstance;

BOOL UNLOADING = FALSE;
BOOL NOTFOUND = FALSE;
BOOL INITIALIZED = FALSE;

WNDCLASSEX wndClass;

using namespace SDK;

void FOVModifier()
{
	while (true)
	{
		if (onoff)
		{
			//Memory reading
			Uworld = readMemory<DWORD_PTR>(Driver, processID, BaseAddress + SDK::Offsets::Game::UWorld);
			if (Uworld == (DWORD_PTR)nullptr)
				continue;


			DWORD_PTR Gameinstance = readMemory<DWORD_PTR>(Driver, processID, Uworld + 0x170);
			if (Gameinstance == (DWORD_PTR)nullptr)
				continue;


			DWORD_PTR LocalPlayers = readMemory<DWORD_PTR>(Driver, processID, Gameinstance + 0x38);
			if (LocalPlayers == (DWORD_PTR)nullptr)
				continue;


			Localplayer = readMemory<DWORD_PTR>(Driver, processID, LocalPlayers);
			if (Localplayer == (DWORD_PTR)nullptr)
				continue;


			Ulevel = readMemory<DWORD_PTR>(Driver, processID, Uworld + 0x30);
			if (Ulevel == (DWORD_PTR)nullptr)
				continue;

				writeMemory<float>(Driver, processID, Localplayer + 0x420, fov);

		}
		Sleep(Cycle);
	}		
}

int WINAPI main(HINSTANCE Hinstance, HINSTANCE hSecInstance, LPSTR nCmdLine, INT nCmdShow)
{
	if (Driver == INVALID_HANDLE_VALUE)
	{
		printf("A Error Occured\nPlease Contact The Developers!\nRestarting your pc may fix the Problem!");
		Sleep(10000000000);

	}
	else
	{
		while (hwnd == NULL)
		{
			hwnd = FindWindowA(0, _xor_(tWindowName).c_str());
			Sleep(1000);
			system("cls");
		}
		::ShowWindow(::GetConsoleWindow(), SW_HIDE);

		GetWindowThreadProcessId(hwnd, &processID);
		info_t Input_Output_Data;
		Input_Output_Data.pid = processID;
		unsigned long int Readed_Bytes_Amount;
		DeviceIoControl(Driver, ctl_base, &Input_Output_Data, sizeof Input_Output_Data, &Input_Output_Data, sizeof Input_Output_Data, &Readed_Bytes_Amount, nullptr);
		BaseAddress = (unsigned long long int)Input_Output_Data.data;

		GetWindowRect(hwnd, &tSize);
		Globals::rWidth = tSize.right - tSize.left;
		Globals::rHeight = tSize.bottom - tSize.top;
		Globals::tWnd = FindWindow(NULL, tWindowName);

		CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)FOVModifier, NULL, NULL, NULL);
		CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)UpdateWinPosition, NULL, NULL, NULL);
		CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)Menu::Update, NULL, NULL, NULL);

		GetWindowThreadProcessId(Globals::tWnd, &procID);
		Globals::hGame = OpenProcess(PROCESS_ALL_ACCESS, FALSE, procID);

		Globals::hWnd = InitializeWin((HINSTANCE)Hinstance);
		MSG uMessage;

		ShowWindow(Globals::hWnd, SW_SHOW);

		INITIALIZED = TRUE;

		Sleep(1100);

		while (!UNLOADING) {
			if (PeekMessage(&uMessage, Globals::hWnd, 0, 0, PM_REMOVE)) {
				DispatchMessage(&uMessage);
				TranslateMessage(&uMessage);
			}
			if (UNLOADING) {
				HWND hMsg = FindWindow(NULL, "Info");

				if (hMsg) {
					std::this_thread::sleep_for(std::chrono::seconds(3));
					SendMessageA(hMsg, WM_CLOSE, 0, 0);
				}
			}
		}
		return 0;
	}
	getchar();
}

//ImGui
HWND WINAPI InitializeWin(HINSTANCE hInst) {

	wndClass.cbSize = sizeof(WNDCLASSEX);
	wndClass.cbClsExtra = NULL;
	wndClass.cbWndExtra = NULL;
	wndClass.hCursor = LoadCursor(0, IDC_ARROW);
	wndClass.hIcon = LoadIcon(0, IDI_APPLICATION);
	wndClass.hIconSm = LoadIcon(0, IDI_APPLICATION);
	wndClass.hbrBackground = (HBRUSH)CreateSolidBrush(RGB(0, 0, 0));
	wndClass.hInstance = hInst;
	wndClass.lpfnWndProc = WindowProc;
	wndClass.lpszClassName = WINNAME;
	wndClass.lpszMenuName = WINNAME;
	wndClass.style = CS_VREDRAW | CS_HREDRAW;

	if (!RegisterClassEx(&wndClass)) {
		exit(1);
	}

	Globals::hWnd = CreateWindowEx(WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED, WINNAME, WINNAME, WS_POPUP, 1, 1, Globals::rWidth, Globals::rHeight, 0, 0, 0, 0);
	SetLayeredWindowAttributes(Globals::hWnd, 0, 255, LWA_ALPHA);
	SetLayeredWindowAttributes(Globals::hWnd, RGB(0, 0, 0), 0, ULW_COLORKEY);

	D3DInitialize(Globals::hWnd);

	return Globals::hWnd;
}

void UpdateWinPosition() {
	while (!UNLOADING) {
		UpdateSurface(Globals::hWnd);
		std::this_thread::sleep_for(std::chrono::seconds(5));
	}
}

void WINAPI UpdateSurface(HWND hWnd) {
	RECT wSize;
	HWND tWnd;

	tWnd = FindWindow(NULL, tWindowName);

	if (!tWnd && hWnd && !UNLOADING && !NOTFOUND) { exit(0); UNLOADING = TRUE; }

	if (tWnd) {
		GetWindowRect(tWnd, &wSize);
		Globals::rWidth = wSize.right - wSize.left;
		Globals::rHeight = wSize.bottom - wSize.top;

		DWORD dwStyle = GetWindowLong(tWnd, GWL_STYLE);
		if (dwStyle & WS_BORDER)
		{
			wSize.top += 23; Globals::rHeight -= 23;
			//wSize.left += 10; rWidth -= 10;
		}

		if (hWnd) {
			MoveWindow(hWnd, wSize.left, wSize.top, Globals::rWidth, Globals::rHeight, true);
		}
	}
}

LRESULT CALLBACK WindowProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam) {
	switch (uMessage) {
	case WM_CREATE:
		DwmExtendFrameIntoClientArea(hWnd, &MARGIN);
		break;

	case WM_PAINT:
		D3DRender();
		break;

	case WM_DESTROY:
		ImGui::Shutdown();
		DeleteObject(wndClass.hbrBackground);
		DestroyCursor(wndClass.hCursor);
		DestroyIcon(wndClass.hIcon);
		DestroyIcon(wndClass.hIconSm);

		PostQuitMessage(1);
		break;

	default:
		ImGui_ImplWin32_WndProcHandler(hWnd, uMessage, wParam, lParam);
		return DefWindowProc(hWnd, uMessage, wParam, lParam);
		break;
	}
}
