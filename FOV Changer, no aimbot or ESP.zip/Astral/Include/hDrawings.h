#ifndef HDRAWFUNC_H
#define HDRAWFUNC_H

#include "hDirectX.h"

#pragma warning( disable : 4244 ) //remove the incoming warns
#pragma warning( disable : 4996 ) //remove the incoming warns

#include <d3dx9.h>
#include <d3d9.h>
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")

void GradientFunc(int x, int y, int w, int h, int r, int g, int b, int a);
void DrawLine(float x, float y, float xx, float yy, int r, int g, int b, int a);
void DrawBox(float x, float y, float width, float height, float px, int r, int g, int b, int a, bool filled);
void DrawCircle(float x, float y, float radius, float thickness, float r, float g, float b, bool filled);

int DrawString(const char* String, int x, int y, int r, int g, int b, ID3DXFont* ifont);
int DrawShadowString(const char* String, int x, int y, int r, int g, int b, ID3DXFont* ifont);

#endif