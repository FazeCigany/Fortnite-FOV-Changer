#ifndef Menu_h
#define Menu_h

#include "Main.h"

extern bool MenuVisable;

extern float fov;
extern bool onoff;
extern float ads;
extern int Cycle;

namespace Menu {
	void DrawVisuals(IDirect3DDevice9* pDevice);
	void DrawMenu(IDirect3DDevice9* pDevice);
	void Update();
}

#endif /* defined(__Julian_Story__Menu__) */